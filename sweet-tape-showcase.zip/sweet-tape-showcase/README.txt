SWEET TAPE — SHOWCASE MEDIA
Captured from the finished web project (commit d25661f).

VIDEO
01-project-showreel-1920x1080.mp4 — 25.2s landscape reel: hero, live customizer, paper tear, portal, factory, particles, personalised roll, footer.
02-factory-journey-1920x1080.mp4 — 18.7s landscape clip focused on The Other Side.
03-factory-journey-1080x1920.mp4 — 15.2s vertical capture of the actual responsive mobile layout, suitable for Reels, Stories, and TikTok.
04-portal-preview.gif — 640 x 360 looping preview for case studies or messages.

MP4 files use H.264, 24 fps, yuv420p, fast-start playback. Clips are silent.
Videos are captured frame by frame from the actual browser-rendered project with presentation cuts; no browser chrome is included.

STILLS
Desktop screenshots: 1920 x 1080 PNG.
Mobile screenshots: 1080 x 1920 PNG.
Product cutouts, if included: transparent PNG renders of the real 3D preview in rose, yellow, and orange.
Use 05-factory-desktop.png as a project cover, 04-portal-desktop.png to introduce the interaction, and 07-custom-roll-desktop.png for the result.

LIVE PROJECT
https://ejaubashi.github.io/t015/
Direct experiment: https://ejaubashi.github.io/t015/#factory

The production website was not modified while making this pack.
